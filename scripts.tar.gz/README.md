# NCAE 2025

Some scripts for NCAE 2025. WGU Team 1.
