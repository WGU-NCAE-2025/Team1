# Instructions

## Copy paste and then run the scripts in this order

### *(If you CAN'T copy paste because of you only have a terminal, then MANUALLY CONFIGURE YOUR IP/NETWORK SHIT)*
YOU WILL THEN BE ABLE TO DOWNLOAD WHAT YOU NEED WITH A SIMPLE `curl` COMMAND.

Remember to give them executable permissions!
`sudo chmod 700 <script>.sh`

Run them! With `sudo`!
1. `sudo ./1-rsyncBackup.sh`
2. `sudo ./2-setupLoggingUser.sh`
3. `sudo ./3-networkSetup.sh`
4. Find the 
